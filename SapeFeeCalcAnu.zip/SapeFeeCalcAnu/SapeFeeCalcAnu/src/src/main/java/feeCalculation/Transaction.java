package src.main.java.feeCalculation;

import java.util.ArrayList;
import java.util.List;

public class Transaction {



	public static void main(String[] args) {
		
		String fileLoc = Constants.FILE_LOCATION;
		List<TransactionPOJO> transactionList = new ArrayList<>();
		transactionList = FileReader.readFile(Constants.FILE_CSV, fileLoc);
		TransactionFeeCalculator feeCalc = new TransactionFeeCalculator();
		transactionList = feeCalc.feeCaluclator(transactionList);
		TransactionDisplay.display(transactionList);
	}


}
