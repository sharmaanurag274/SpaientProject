package src.main.java.feeCalculation;

import java.text.SimpleDateFormat;
import java.util.List;

public class TransactionDisplay {

	public static void display(List<TransactionPOJO> transactionList) {
		
		if(transactionList != null && transactionList.size()>0) {
		System.out.println("Calculated Fees:-");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Client Id | Transaction Type | Transaction Date | Priority       | Processing Fee |");
		for (TransactionPOJO trans : transactionList) {
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			String date = sdf.format(trans.getTransactionDate());
			System.out.println("--------------------------------------------------------------------------------");
			System.out.println(trans.getClientId() + "\t  | " + trans.getTransactionType() + " \t     | " +
			date + "\t| " + (trans.getPriority() ? "HIGH \t" : "NORMAL") + " \t | "+
			trans.getTransactionFees() + "\t|");
		}
	}
	
	}
}
