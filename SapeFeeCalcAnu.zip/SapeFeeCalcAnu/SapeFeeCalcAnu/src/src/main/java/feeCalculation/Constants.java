package src.main.java.feeCalculation;

public class Constants {

	public static String FILE_TXT = "txt";
	public static String FILE_CSV = "csv";
	public static String FILE_XML = "xml";
	public static String DELIMITER = ",";
	public static Double FEES_INTRADAY_TEN = 10d;
	public static Double FEES_FIVE_HUNDRED = 500d;
	public static Double FEES_ONE_HUNDRED = 100d;
	public static Double FEES_FIFTY = 50d;
	public static String TRANSACTIONTYPE_SELL = "SELL";
	public static String TRANSACTIONTYPE_WITHDRAW = "WITHDRAW";
	public static String TRANSACTIONTYPE_BUY = "BUY";
	public static String TRANSACTIONTYPE_DEPOSIT = "DEPOSIT";
	public static String FILE_LOCATION = "Sample.csv";
}
