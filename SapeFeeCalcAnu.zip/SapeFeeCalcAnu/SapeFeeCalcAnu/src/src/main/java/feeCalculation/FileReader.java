package src.main.java.feeCalculation;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class FileReader {

	public static List<TransactionPOJO> readFile(String fileType, String fileLoc) {
		
		List<TransactionPOJO> transaction = new ArrayList<>();
		if(fileType.equalsIgnoreCase(Constants.FILE_CSV)) {
			transaction = readCsvFile(fileLoc);
		}else if (fileType.equalsIgnoreCase(Constants.FILE_TXT)) {
			transaction = readCsvFile(fileLoc);
		}else if(fileType.equalsIgnoreCase(Constants.FILE_XML)) {
			transaction = readCsvFile(fileLoc);
		}
		return transaction;
		
	}

	private static List<TransactionPOJO> readCsvFile(String fileLoc) {

		List<TransactionPOJO> transactionDetails = new ArrayList<>();
		try {
			ClassLoader cl = FileReader.class.getClassLoader();
			//File f1 = new File(cl.getResource("./SapeFeeCalcAnkit/src/src/main/resource/Sample.csv").getFile());
			File f = new File(fileLoc);
			BufferedReader reader = new BufferedReader(new java.io.FileReader(f));
			String line;
			while((line = reader.readLine()) != null) {
				String[] string= line.split(Constants.DELIMITER);
				TransactionPOJO trans = new TransactionPOJO();
				trans = createTransaction(string);
				transactionDetails.add(trans);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return transactionDetails;
	}

	private static TransactionPOJO createTransaction(String[] string) {

		
		TransactionPOJO transaction = new TransactionPOJO();
		
		transaction.setExternalTransactionId(string[0]);
		transaction.setClientId(string[1]);
		transaction.setSecurityId(string[2]);
		transaction.setTransactionType(string[3]);
		try {
			transaction.setTransactionDate(new SimpleDateFormat("dd/MM/yyyy").parse(string[4]));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		transaction.setMarketValue(Double.parseDouble(string[5]));
		if((string[6]!=null || !(string[6] == "")) && string[6].equalsIgnoreCase("Y")) {
			transaction.setPriority(true);
		}else if((string[6]!=null || !(string[6] == "")) && string[6].equalsIgnoreCase("N")){
			transaction.setPriority(false);
		}
		return transaction;	
	
	}
}
