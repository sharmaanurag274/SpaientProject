package src.main.java.feeCalculation;

import java.util.Date;

public class TransactionPOJO {
	
	private String ExternalTransactionId;
	private String ClientId;
	private String SecurityId;
	private String transactionType;
	private Date transactionDate;
	private Double marketValue;
	private Boolean priority;
	private Double transactionFees;
	public String getExternalTransactionId() {
		return ExternalTransactionId;
	}
	public void setExternalTransactionId(String externalTransactionId) {
		ExternalTransactionId = externalTransactionId;
	}
	public String getClientId() {
		return ClientId;
	}
	public void setClientId(String clientId) {
		ClientId = clientId;
	}
	public String getSecurityId() {
		return SecurityId;
	}
	public void setSecurityId(String securityId) {
		SecurityId = securityId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public Double getMarketValue() {
		return marketValue;
	}
	public void setMarketValue(Double marketValue) {
		this.marketValue = marketValue;
	}
	public Boolean getPriority() {
		return priority;
	}
	public void setPriority(Boolean priority) {
		this.priority = priority;
	}
	public Double getTransactionFees() {
		return transactionFees;
	}
	public void setTransactionFees(Double transactionFees) {
		this.transactionFees = transactionFees;
	}
	
	
}
