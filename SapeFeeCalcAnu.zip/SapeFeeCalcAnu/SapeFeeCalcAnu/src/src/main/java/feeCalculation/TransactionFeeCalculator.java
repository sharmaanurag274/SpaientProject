package src.main.java.feeCalculation;

import java.util.ArrayList;
import java.util.List;

public class TransactionFeeCalculator {

	public List<TransactionPOJO> feeCaluclator(List<TransactionPOJO> transactioDetails){
		
		List<TransactionPOJO> transactionList = new ArrayList<>();
		
		if(transactioDetails != null && transactioDetails.size()>0) {
			for (TransactionPOJO transaction : transactioDetails) {
				
				if(isIntraDayTransaction(transaction, transactioDetails)) {
					transaction.setTransactionFees(Constants.FEES_INTRADAY_TEN);
				}else if(transaction.getPriority()) {
					transaction.setTransactionFees(Constants.FEES_FIVE_HUNDRED);
				}else if(!transaction.getPriority()) {
					if(transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_SELL) 
							|| transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_WITHDRAW)) {
						transaction.setTransactionFees(Constants.FEES_ONE_HUNDRED);
					}else if(transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_BUY) 
							|| transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_DEPOSIT)) {
						transaction.setTransactionFees(Constants.FEES_FIFTY);
					}
				}
				transactionList.add(transaction);
			}
		}
		
		return transactionList;
	}

	private boolean isIntraDayTransaction(TransactionPOJO transaction, List<TransactionPOJO> transactioDetails) {

		for (TransactionPOJO trans : transactioDetails) {
			if(trans.getClientId().equalsIgnoreCase(transaction.getClientId())
					&& trans.getSecurityId().equalsIgnoreCase(transaction.getSecurityId())
					&& trans.getTransactionDate().compareTo(transaction.getTransactionDate())==0) {
				if((trans.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_SELL) && transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_BUY))
						|| trans.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_BUY) && transaction.getTransactionType().equalsIgnoreCase(Constants.TRANSACTIONTYPE_SELL)){
							return true;
						}
			}
		}
		
		return false;
	}
}
